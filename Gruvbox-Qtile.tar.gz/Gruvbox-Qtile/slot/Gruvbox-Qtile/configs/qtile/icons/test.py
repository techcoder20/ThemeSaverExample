import os

FolderPath = '/home/rpicoder/.config/qtile'

for image in os.listdir(f'{FolderPath}/icons'):
    os.system(f'convert {image} -fill "#EBDBB2" -colorize 100 {image}')

